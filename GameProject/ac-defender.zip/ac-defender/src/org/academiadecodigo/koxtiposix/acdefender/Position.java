package org.academiadecodigo.koxtiposix.acdefender;

public class Position {
    private int z;

    public Position() {

    }

    public int x() {

        return 0;
    }

    public int y() {

        return 0;
    }
}
