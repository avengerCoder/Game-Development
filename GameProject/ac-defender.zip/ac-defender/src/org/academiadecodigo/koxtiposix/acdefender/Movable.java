package org.academiadecodigo.koxtiposix.acdefender;

public interface Movable {

}
